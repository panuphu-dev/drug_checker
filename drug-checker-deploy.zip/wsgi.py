"""WSGI entry point for PythonAnywhere deployment."""
from app import app as application
